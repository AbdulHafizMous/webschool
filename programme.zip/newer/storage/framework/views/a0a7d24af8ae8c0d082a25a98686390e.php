<?php
	use Illuminate\Support\Facades\BD;
	use Illuminate\Support\Facades\Route;

	if ($sess != '0') {

$rq = DB::select(" SELECT * FROM `moyennes02` 
		WHERE annee = ?
		AND code_classe = ?
		AND serie = ?
		AND groupe = ?
		AND id_session = ? ", ["{$an}", "{$c}",
		"{$s}","{$g}", "{$sess}"]);

	}
	else {
		
		$rq = DB::select(" SELECT * FROM `moyennes03` 
      WHERE annee = ?
      AND code_classe = ?
      AND serie = ?
      AND groupe = ? ", ["{$an}", "{$c}",
      "{$s}","{$g}"]);

	}


?>



<?php $__env->startSection('content'); ?> 
	<header id="head" class="secondary"></header>

	<!-- container -->
	<div class="container">
        <div class="row">
			
			<!-- Article main content -->
			<article class="col-xs-12 maincontent">
			
			
			<div class=" bg-success ">
							<h3 class="thin text-center">Bulletins des Apprenants : ( <?php echo e($c); ?>  <?php echo e($s); ?>  <?php echo e($g); ?> ) ~ <?php echo e($nsess); ?>  </h3>
							</div>
							<hr>
				<div>
				<div class="panel panel-default">
					<div class="panel-body ">
	
        <table width="100%" class="table table-secondary table-striped bg-info" id="tbl">
	<thead class="thead-dark">
        <tr class="bg-primary" >
            <th class="text-center" width="10%">Matricule</th>
            <th class="text-center" width="20%">Nom</th>
            <th class="text-center" width="40%">Prénoms</th>
            <th class="text-center" width="15%">Conduite</th>
            <th class="text-center" width="15%">MG</th>
            <th class="text-center" width="15%">Mention</th>
            <th class="text-center" width="15%">Voir</th>
            <th class="text-center" width="15%">Télecharger</th>
        </tr>
	</thead>
	<tbody id="tbody">
		<?php 
		foreach ($rq as $key) {
			if ($sess == '0') {
				$mg = number_format($key->moyan, '2');
				// $lien = ""
			}
			else {
				$mg = number_format($key->moygac, '2');
			}
			

			$ment = '';

			if ($mg < 10) {
				# code...
				$ment = 'Insuffisant';
			}
			elseif ($mg < 12) {
				# code...
				$ment = 'Passable';
			}
			elseif ($mg < 14) {
				# code...
				$ment = 'Assez Bien';
			}
			elseif ($mg < 16) {
				# code...
				$ment = 'Bien';
			}
			elseif ($mg < 18) {
				# code...
				$ment = 'Très Bien';
			}
			else {
				# code...
				$ment = 'Excellent';
			}

			$see = url('bullfile', ['sess' => $sess, 'mat' => $key->mat_eleve]);
			$dwnl = url('pdf_bull', ['sess' => $sess, 'mat' => $key->mat_eleve]);
			$tmp = "$sess . $key->mat_eleve";

			echo "<tr class=\" t_$key->mat_eleve\">
				<input type=\"text\" style=\"display: none;\" value=\"$key->mat_eleve\" name=\"matricules[]\" id=\"hide\" >
					<td class=\"text-center\">$key->mat_eleve</td>
					<td class=\"text-center\">$key->nom</td>
					<td class=\"text-center\">$key->prenom</td>
					<td class=\"text-center\">$key->note</td>
					<td class=\"text-center\">$mg</td>
					<td class=\"text-center\">$ment</td>
					<form action=\"$see\" method=\"\">
						<td class=\"text-center\"> <button type=\"submit\" class=\"btn btn-secondary \"> <i class=\"fa fa-eye\" aria-hidden=\"false\"></i> </button> </td>
					</form>
					
						<td class=\"text-center\"> <span name=\"$tmp\" class=\"btn btn-secondary \" id=\"download\"> <i class=\"fa fa-download\" aria-hidden=\"false\"></i> </span> </td>
					
				</tr>
					";
					
		}
		// <td class=\"text-center\"> <a href=\"{{url('bullfile', ['sess' => $sess, 'mat' => $key->mat_eleve]}})\" class=\"btn btn-secondary\"> Voir ☺ </a> </td>
		// foreach ([$c, $s, $g] as $key) {
		// 	echo "<input type=\"text\" style=\"display: none;\" value=\"$key\" name=\"hide\" id=\"hide\" >";
		// }

		// <form action=\"$dwnl\" method=\"\">
		// </form>
		

		?>

	</tbody>
    </table>

</div>

</div>


	  
    
</article>
<!-- /Article -->




</div>
</div>	<!-- /container -->

<?php $__env->stopSection(); ?> 

<?php $__env->startSection('jsfiles'); ?> 
<script src="<?php echo e(url('js/jquery-3.6.0.min.js')); ?>"></script>
<script src="<?php echo e(url('js/html2pdf.bundle.min.js')); ?>"></script>
<script>
	document.addEventListener('DOMContentLoaded', function() {
		document.querySelectorAll('#download').forEach((btn) => {
			btn.addEventListener('click', function() {  
				var name = btn.attributes.getNamedItem('name').value;
				var sess = name.split(' . ')[0];
				var mat = name.split(' . ')[1];
				
			// #download=id du bouton
			fetch('pdf_bull/'+sess+'/'+mat)  // Remplacez '/my-route' par l'URL de votre route qui renvoie simplement la view (reurn view(...))
				.then(response => response.text())
				.then(html => {
					var opt = {
						margin:       [-0.2,-0.5,-0.5,-0.5],
						filename:     sess+'_'+mat+'_bull.pdf', // #nom du document
						image:        { type: 'jpeg', quality: 1 },
						html2canvas:  { scale: 4 },
						jsPDF:        { unit: 'in', format: 'letter', orientation: 'portrait' }
						
					};

					// Crée un objet PDF.
					var worker = html2pdf().from(html).set(opt).save();
				});
				alert(sess + mat);
			});
		})
		
		



	});
</script>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('admlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\newer\resources\views/bulletin/tab_bull.blade.php ENDPATH**/ ?>