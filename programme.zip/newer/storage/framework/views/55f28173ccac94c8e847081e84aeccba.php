
<h1>Enregistrement Effectué </h1>
<?php /**PATH C:\wamp64\www\newer\resources\views/test2.blade.php ENDPATH**/ ?>