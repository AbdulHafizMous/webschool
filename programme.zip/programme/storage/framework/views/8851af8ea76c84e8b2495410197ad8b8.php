<?php
use Illuminate\Support\Facades\BD;

$rqan = DB::select(' SELECT MAX(infoetbs.annee) as annee
FROM `infoetbs`');

$rqs = DB::select('SELECT *
FROM sessions');

$idsact = 0;

foreach ($rqs as $key) {
	if ($key->act == '1') {
		$idsact = intval($key->id_session);
	}
}

$rq = DB::select('SELECT code_classe, serie, groupe, SUM(CASE WHEN int_act > 1 THEN 0 ELSE 1 END) AS intv, SUM(CASE WHEN dev_act = 6 THEN 0 ELSE 1 END) AS devv
FROM `enseignement` 
WHERE annee = ?
GROUP BY code_classe, serie, groupe;', ["{$rqan[0]->annee}"]);
 
$code = "";
$ok1 = 0;

foreach ($rq as $key) {
	$code = $code."<tr class=\"$key->code_classe . $key->serie . $key->groupe\">
			<td class=\"text-center\">$key->code_classe ~ $key->serie ~ $key->groupe</td>
			";

	foreach ($rqs as $key2) {
		if ($key2->id_session < $idsact ) {
			$code = $code."<td class=\"text-center text-success\">V</td>";
		}
		elseif ($key2->id_session == $idsact) {
			if($key->intv == '0' && $key->devv == '0'){
				$code = $code."<td class=\"text-center text-success\">V</td>";
			}
			else {
				$code = $code."<td class=\"text-center text-danger\">X</td>";
				$ok1 += 1;
			}
		}
		else {
			$code = $code."<td class=\"text-center text-danger\">X</td>";
			$ok1 += 1;
		}
	}
	
}

$code = $code." </tr> ";

$ok2 = $ok1 == 0 ? '' : 'disabled';


?>








<?php $__env->startSection('content'); ?> 
	<header id="head" class="secondary"></header>

	<!-- container -->
	<div class="container">

		<div class="row">

			<?php
				if (isset($ok)) {
					echo "Enregistrement effectué";
				}
				if (isset($oktxt)) {
					echo $oktxt;
				}	
			?>
			
			<!-- Article main content -->
			<article class="col-xs-12 maincontent">
				<header class="page-header">
					<h1 class="page-title">Validation</h1>
				</header>
				
				<div class="col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2">
					<div class="panel panel-default">
						<div class="panel-body">
							<h3 class="thin text-center">Valider l'Année Scolaire en Cours : ~ <?php echo e($rqan[0]->annee); ?> ~ </h3>
						<hr>

							<form method="" action="<?php echo e(url('van_save')); ?>">
								<div class="row m-auto d-flex" style="display: flex; flex-direction: row; justify-content: space-between; justify-items: center;">
									<div class="col-md-6 col-sm-6">
										<a class="btn btn-warning"  href="<?php echo e(url('saisie_nt')); ?>">
										  Saisie de Notes
									  </a>
									</div>
								  <div class=" text-right col-md-6 col-sm-6">
										<button class="btn btn-success btn-action " type="submit" id="enregistrer" <?php echo e($ok2); ?>>
										  Enrégistrer
									  </button>
								  </div>
							  </div>
							

								<div class="panel panel-default">
									<div class="panel-body ">
					
										<table width="100%" class="table table-secondary table-striped bg-info" id="tbl">
											<thead class="thead-dark">
												<tr class="bg-primary" >
													<th class="text-center" width="50%">Classe ~ Série ~ Groupe</th>
													<?php $__currentLoopData = $rqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														<th class="text-center" width="15%"><?php echo e($s->nom_session); ?></th>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													
												</tr>
											</thead>
											<tbody id="tbody">
												
												<?php 
												
										
												echo $code;
												
										
												?>
										
											</tbody>
										</table>
								
									</div>
								
								</div>
							</form>
						</div>
					</div>

				</div>
				
			</article>
			<!-- /Article -->

		</div>
	</div>	<!-- /container -->
	
<?php $__env->stopSection(); ?> 


<?php $__env->startSection('jsfiles'); ?> 
<script src="<?php echo e(url('js/jquery-3.6.0.min.js')); ?>"></script>

<script>

	
</script>
<?php $__env->stopSection(); ?> 

<?php echo $__env->make('admlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\newer\resources\views/valider/van.blade.php ENDPATH**/ ?>