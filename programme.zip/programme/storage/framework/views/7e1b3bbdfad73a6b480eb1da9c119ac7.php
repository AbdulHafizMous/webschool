<?php 

use Illuminate\Support\Facades\BD;

$rq = [];

$v12 = $v10 = $v14 = $v16 = $v18 = $v20 = 0;

if ($sess == '0') {
  # code...
  $rq = DB::select(" SELECT * FROM `moyennes03` 
      WHERE annee = ?
      AND code_classe = ?
      AND serie = ?
      AND groupe = ?", ["{$an}", "{$c}",
      "{$s}","{$g}"]);

      $vpf = $vpfo = number_format($rq[0]->moyan, '2');
 
foreach ($rq as $key) {
  $mg = number_format($key->moyan, '2');

  // $ment = '';

  if ($mg < 10) {
    # code...
    // $ment = 'Insuffisant';
    $v10++;
  }
  elseif ($mg < 12) {
    # code...
    // $ment = 'Passable';
    $v12++;
  }
  elseif ($mg < 14) {
    # code...
    // $ment = 'Assez Bien';
    $v14++;
  }
  elseif ($mg < 16) {
    # code...
    // $ment = 'Bien';
    $v16++;
  }
  elseif ($mg < 18) {
    # code...
    // $ment = 'Très Bien';
    $v18++;
  }
  else {
    # code...
    // $ment = 'Excellent';
    $v20++;
  }

  if ($mg < $vpf) {
    $vpf = $mg;
  }
  if ($mg > $vpfo) {
    $vpfo = $mg;
  }

      
}

$nsess = 'Annuelles';

}
else {

  $rq = DB::select(" SELECT * FROM `moyennes02` 
      WHERE annee = ?
      AND code_classe = ?
      AND serie = ?
      AND groupe = ?
      AND id_session = ? ", ["{$an}", "{$c}",
      "{$s}","{$g}", "{$sess}"]);

      $vpf = $vpfo = number_format($rq[0]->moygac, '2');

foreach ($rq as $key) {
  $mg = number_format($key->moygac, '2');

  // $ment = '';

  if ($mg < 10) {
    # code...
    // $ment = 'Insuffisant';
    $v10++;
  }
  elseif ($mg < 12) {
    # code...
    // $ment = 'Passable';
    $v12++;
  }
  elseif ($mg < 14) {
    # code...
    // $ment = 'Assez Bien';
    $v14++;
  }
  elseif ($mg < 16) {
    # code...
    // $ment = 'Bien';
    $v16++;
  }
  elseif ($mg < 18) {
    # code...
    // $ment = 'Très Bien';
    $v18++;
  }
  else {
    # code...
    // $ment = 'Excellent';
    $v20++;
  }

  if ($mg < $vpf) {
    $vpf = $mg;
  }
  if ($mg > $vpfo) {
    $vpfo = $mg;
  }

      
}
}




    echo "<script> 
      
      var dtlst = ['$v10', '$v12', '$v14', '$v16', '$v18', '$v20' ]; 

      var listmoyenne=[['M < 10', 'Insuffisant', '$v10'],['10 <= M < 12', 'Passable', '$v12'],['12 <= M < 14', 'Assez Bien', '$v14'], 
      ['14 <= M < 16', 'Bien', '$v16'], ['16 <= M < 18', 'Très Bien', '$v18'], ['18 <= M ', 'Excellent', '$v20']];

      var listmoyenn=[['Plus forte Moyenne','$vpfo'],['Plus faible Moyenne','$vpf']];
      
      </script>";

?>




<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport"    content="width=device-width, initial-scale=1.0">
	<meta name="description" content="">
	<meta name="author"      content="Sergey Pozhilov ">
	
	<title>Accueil -  Progressus</title>

	<link rel="shortcut icon" href="images/gt_favicon.png">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/font-awesome.min.css">

	<!-- Custom styles for our template -->
	<link rel="stylesheet" href="css/bootstrap-grid.min.css">
	<link rel="stylesheet" href="css/main.css">
	<link rel="stylesheet" href="css/style.css">

	<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
	<!--[if lt IE 9]>
	<script src="assets/js/html5shiv.js"></script>
	<script src="assets/js/respond.min.js"></script>
	<![endif]-->

  <script src="js/bootstrap.bundle.js"></script>
  <script src="js/chart.js"></script>

</head>

<body>
  

  <div class="container-fluid px-5 mt-3">
    
    <div class=" bg-light ">
            <h3 class="thin text-center">Statistiques des Moyennes Générales : ~ <?php echo e($nsess); ?> ~ ( <?php echo e($c); ?>  <?php echo e($s); ?>  <?php echo e($g); ?> )</h3>
            </div>
            <hr>
  </div>



<div class="container-fluid p-5">
<div class="row" id="contenutrim1">
      <div class="col-md-6">
        <div class="mt-4">
        <div>
          <p class="text-center bg-success text-white">BILAN STATISTIQUE</p>
           <table border=1px class="table table-warning table-striped bg-info" id="tbl1" width=100%>
            <thead>
              <th class="text-center">Moyenne </th>
              <th class="text-center">Mention </th>
              <th class="text-center">Effectif </th>
            </thead>
            <tbody id="tbody1"></tbody>
           </table>
        </div>
        <div>
        <p class="text-center bg-success text-white mt-5">MOYENNE</p>
           <table border=1px class="table table-secondary table-striped bg-info" id="tbll1" width=100%>
            <thead>
              <th class="text-center">Type </th>
              <th class="text-center">Moyenne </th>
            </thead>
            <tbody id="tbodyy1"></tbody>
           </table>
        </div>
        </div>
      </div>

     <div class="col-md-6">
        <div class="mb-4">
          <canvas id="barChart1" width="400" height="200"></canvas>
        </div>
        <div>
        <canvas id="doughnutChart1" width="400" height="400"></canvas>
        </div>       
    </div>
  </div>
</div>


<script>
var contenutrim1 = document.getElementById("contenutrim1");
// var contenutrim2 = document.getElementById("contenutrim2");
// var contenutrim3 = document.getElementById("contenutrim3");
// var contenuannulle = document.getElementById("contenuannuelle");
var trim1 =document.getElementById("trim1");
// var trim2 =document.getElementById("trim2");
// var trim3 =document.getElementById("trim3");
// var annuelle=document.getElementById("annu");
trim1.appendChild(contenutrim1);
// trim2.appendChild(contenutrim2);
// trim3.appendChild(contenutrim3);
// annuelle.appendChild(contenuannulle);
  
</script>
<script>
  var triggerTabList = [].slice.call(document.querySelectorAll('#myTab a'))
triggerTabList.forEach(function (triggerEl) {
  var tabTrigger = new bootstrap.Tab(triggerEl)

  triggerEl.addEventListener('click', function (event) {
    event.preventDefault()
    tabTrigger.show()
  })
})
</script>
</body>



<script src="js/bootstrap.bundle.js"></script>
  <script src="js/chart.js"></script>

  
  <script src="js/headroom.min.js"></script>
	<script src="js/jQuery.headroom.min.js"></script>
  <script src="js/tab_satateffmat.js"></script>
  <script src="js/tab_statmoymat.js"></script>
  <script src="js/charts_statmat.js"></script>
</html><?php /**PATH C:\wamp64\www\newer\resources\views/statistique/tab_statsess.blade.php ENDPATH**/ ?>