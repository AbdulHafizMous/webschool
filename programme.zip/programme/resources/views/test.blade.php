@extends('index')

@section('content') 
    <h1>oke</h1>
@endsection 